const $ = id => document.getElementById(id);
const n = id => Math.max(0, Number($(id).value) || 0);
const money = x => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 0
}).format(Math.max(0, x || 0));

document.querySelectorAll(".tool-strip button").forEach(b => b.onclick = () => {
  document.querySelectorAll(".tool-strip button").forEach(x => x.classList.remove("active"));
  document.querySelectorAll(".app").forEach(x => x.classList.remove("active"));
  b.classList.add("active");
  $(b.dataset.tab).classList.add("active");
  $(b.dataset.tab).scrollIntoView({behavior:"smooth", block:"start"});
});

function oldSlabTax(x, age) {
  x = Math.max(0, x);
  const basic = age >= 80 ? 500000 : age >= 60 ? 300000 : 250000;
  let tax = 0;
  tax += Math.max(0, Math.min(x, 500000) - basic) * 0.05;
  tax += Math.max(0, Math.min(x, 1000000) - 500000) * 0.20;
  tax += Math.max(0, x - 1000000) * 0.30;
  return tax;
}

function newSlabTax(x) {
  x = Math.max(0, x);
  const bands = [
    [400000, 0],
    [800000, 0.05],
    [1200000, 0.10],
    [1600000, 0.15],
    [2000000, 0.20],
    [2400000, 0.25]
  ];
  let tax = 0, previous = 0;
  for (const [limit, rate] of bands) {
    tax += Math.max(0, Math.min(x, limit) - previous) * rate;
    previous = limit;
    if (x <= limit) return tax;
  }
  return tax + Math.max(0, x - 2400000) * 0.30;
}

function surchargeRate(income, regime) {
  if (income <= 5000000) return 0;
  if (income <= 10000000) return 0.10;
  if (income <= 20000000) return 0.15;
  if (income <= 50000000) return 0.25;
  return regime === "new" ? 0.25 : 0.37;
}

function baseTaxAtIncome(income, regime, age) {
  return regime === "new" ? newSlabTax(income) : oldSlabTax(income, age);
}

/*
  Surcharge marginal relief for ordinary slab-rate income.
  This prevents a jump in tax+surcharge from exceeding the income
  above the relevant surcharge threshold.
*/
function applySurchargeAndMarginalRelief(tax, taxableIncome, regime, age) {
  const rate = surchargeRate(taxableIncome, regime);
  if (!rate) return { surcharge: 0, marginalRelief: 0, totalBeforeCess: tax };

  let surcharge = tax * rate;
  let total = tax + surcharge;
  let relief = 0;

  const thresholds = [5000000, 10000000, 20000000, 50000000];
  const threshold = thresholds.slice().reverse().find(t => taxableIncome > t);

  if (threshold) {
    const thresholdTax = baseTaxAtIncome(threshold, regime, age);
    const thresholdTotal = thresholdTax + thresholdTax * surchargeRate(threshold, regime);
    const allowed = thresholdTotal + (taxableIncome - threshold);
    if (total > allowed) {
      relief = total - allowed;
      total = allowed;
      surcharge = Math.max(0, total - tax);
    }
  }

  return { surcharge, marginalRelief: relief, totalBeforeCess: total };
}

function hraExemption() {
  const hra = n("t_hra");
  const rent = n("t_rent");
  const basic = n("t_basic");
  if (!hra || !rent || !basic) return 0;

  const cityFactor = $("t_city").value === "metro" ? 0.50 : 0.40;
  return Math.min(
    hra,
    Math.max(0, rent - 0.10 * basic),
    cityFactor * basic
  );
}

function regimeCalculation(gross, age, resident, regime) {
  let taxable, tax, rebate = 0;

  if (regime === "new") {
    const standardDeduction = Math.min(75000, n("t_salary"));
    taxable = Math.max(0, gross - standardDeduction);
    tax = newSlabTax(taxable);

    // Section 87A: resident individuals only, ordinary slab-rate income.
    if (resident && taxable <= 1200000) {
      rebate = Math.min(60000, tax);
      tax -= rebate;
    } else if (resident && taxable > 1200000) {
      // Marginal relief under the enhanced AY 2026-27 87A limit.
      const taxAt12L = newSlabTax(1200000) - 60000;
      const excess = taxable - 1200000;
      if (tax > excess) {
        rebate = tax - excess;
        tax = excess;
      }
      // taxAt12L is zero under the slab + rebate structure; retained
      // above for clarity/version traceability.
      void taxAt12L;
    }
  } else {
    const standardOld = Math.min(50000, n("t_salary"));
    const hra = hraExemption();

    const deductions =
      standardOld +
      hra +
      Math.min(150000, n("t_80c")) +
      n("t_80d") +
      Math.min(50000, n("t_nps")) +
      Math.min(200000, n("t_home")) +
      n("t_otherded");

    taxable = Math.max(0, gross - deductions);
    tax = oldSlabTax(taxable, age);

    if (resident && taxable <= 500000) {
      rebate = Math.min(12500, tax);
      tax -= rebate;
    }
  }

  const surchargeData = applySurchargeAndMarginalRelief(tax, taxable, regime, age);
  const cess = surchargeData.totalBeforeCess * 0.04;
  const total = surchargeData.totalBeforeCess + cess;

  return {
    taxable,
    taxAfterRebate: tax,
    rebate,
    surcharge: surchargeData.surcharge,
    marginalRelief: surchargeData.marginalRelief,
    cess,
    total
  };
}

function calcTax() {
  try {
    const salary = n("t_salary");
    const other = n("t_other");
    const age = Number($("t_age").value) || 0;
    const resident = $("t_resident").value === "resident";
    const gross = salary + other;

    const old = regimeCalculation(gross, age, resident, "old");
    const neu = regimeCalculation(gross, age, resident, "new");
    const best = old.total < neu.total ? "Old Regime" : "New Regime";
    const diff = Math.abs(old.total - neu.total);

    $("taxResult").innerHTML = `
      <div class="compare">
        <div class="regime ${best === "Old Regime" ? "best" : ""}">
          <h3>Old Regime</h3>
          <div class="row"><span>Taxable income</span><b>${money(old.taxable)}</b></div>
          <div class="row"><span>Tax after rebate</span><b>${money(old.taxAfterRebate)}</b></div>
          <div class="row"><span>Surcharge</span><b>${money(old.surcharge)}</b></div>
          <div class="row"><span>Cess</span><b>${money(old.cess)}</b></div>
          <div class="row total"><span>Final tax</span><b>${money(old.total)}</b></div>
        </div>
        <div class="regime ${best === "New Regime" ? "best" : ""}">
          <h3>New Regime</h3>
          <div class="row"><span>Taxable income</span><b>${money(neu.taxable)}</b></div>
          <div class="row"><span>Tax after rebate</span><b>${money(neu.taxAfterRebate)}</b></div>
          <div class="row"><span>Surcharge</span><b>${money(neu.surcharge)}</b></div>
          <div class="row"><span>Cess</span><b>${money(neu.cess)}</b></div>
          <div class="row total"><span>Final tax</span><b>${money(neu.total)}</b></div>
        </div>
      </div>
      <div class="result">
        <b>${best} is lower in this scenario.</b><br>
        Indicative difference: <strong>${money(diff)}</strong> per year.
      </div>
    `;
  } catch (e) {
    $("taxResult").innerHTML = '<div class="result">Please check the inputs and try again.</div>';
    console.error(e);
  }
}

function calcSalary() {
  const v = Math.max(0, n("s_ctc") - n("s_emp") - n("s_ded") - n("s_tax"));
  $("salaryResult").textContent = money(v);
  $("salaryMonthly").textContent = money(v / 12);
}

function calcEMI() {
  const P = n("e_p"), r = n("e_r") / 1200, m = Math.round(n("e_n") * 12);
  const e = m ? (r ? P * r * (1+r)**m / ((1+r)**m - 1) : P/m) : 0;
  $("emiResult").textContent = money(e);
  $("emiInterest").textContent = money(Math.max(0, e*m - P));
}

function calcSIP() {
  const p = n("p_p"), r = n("p_r") / 1200, m = Math.round(n("p_n") * 12);
  const v = m ? (r ? p * ((1+r)**m - 1) / r * (1+r) : p*m) : 0;
  $("sipResult").textContent = money(v);
  $("sipInvested").textContent = money(p*m);
}

function calcCar() {
  const v = Math.max(0, (n("c_lease") + n("c_run")) * 12 - n("c_save"));
  $("carResult").textContent = money(v);
}

function calcGold() {
  const cost = n("g_w") * n("g_buy") + n("g_make");
  const value = n("g_w") * n("g_now");
  $("goldResult").textContent = money(value - cost);
}

$("taxBtn").onclick = calcTax;

$("aiBtn").onclick = () => {
  const q = $("aiInput").value.trim();
  $("aiResult").textContent = q
    ? "SmartCalc AI: I would identify the right calculator from your question, collect the required inputs, run the deterministic calculation, and explain the result. This demo does not call an external AI service yet."
    : "Please describe what you want to calculate.";
};

document.querySelectorAll("input,select").forEach(x => x.addEventListener("input", () => {
  calcTax();
  calcSalary();
  calcEMI();
  calcSIP();
  calcCar();
  calcGold();
}));

calcTax();
calcSalary();
calcEMI();
calcSIP();
calcCar();
calcGold();
